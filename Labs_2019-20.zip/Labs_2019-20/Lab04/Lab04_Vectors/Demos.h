#ifndef DEMOS_H_
#define DEMOS_H_

#include <string>
#include <vector>

void string_examples();
int readInputFile ( char *inputFile, std::vector<std::string> vContainer);

#endif	// DEMOS_H_