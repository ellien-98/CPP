#include <vector>
#include <string>  

void printStringVector(std::vector<std::string> &vector);
bool isDigit(std::string &word);