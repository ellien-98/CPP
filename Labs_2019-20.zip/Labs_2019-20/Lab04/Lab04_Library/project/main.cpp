#include <iostream>


#include "demos.h"
#include "utils\utils.h"

using namespace std;

// Forward Declaration
void pass_by_val_ref_and_ptr_demo();

///////////////////////////////////////
// Main Function -- code entry point //
// EXECUTION ALWAYS STARTS FROM HERE //
///////////////////////////////////////
int main (int argc, char *argv[]) {

	/* 
	 * Just a print out of the command line arguments
	 * How to add command line arguments in Visual Studio ::
	 *		-- Right Click on Project (Lab3 in this case) in the "Solution Explorer" (usually the most left tab/window)
	 *		-- In the "Configuration Properties" tree menu select the "Debugging"
	 *		-- In the left part of the window insert command line arguments in the "Command Arguments" field
	 *		-- NOTE:: Project Properties are unique per Configuration (Release-Debug)
	 *		--		  That means that if you are in Debug mode and enter command line arguments
	 *		--		  When you change to Release you have to pass them again.
	 *		--		  That goes for everything you do in Project Properties (Additional Include Paths, Libraries etc)
	 */
	for (int i=0; i<argc; ++i) {
		printf ("CMD Line Argument %d is :: %s\n",i, argv[i]);
	}
	printf ("\n");

	vector_demo();

	system ("PAUSE");
	return 0;
}

