#include <iostream>
#include <string>
#include <cstdlib>
#include <vector>
#include "utils\utils.h"


using namespace std;

void vector_demo () {
	// Vectors are containers representing arrays. They change automatically their size as we push back items.
	vector<string> words;
	// In case we know the exact size we will use it is more efficient to reserve the slots
	//words.reserve(100);

	bool finished = false;
	string readString;
	cout << "Write some words (To stop write: END)" << endl;
	do {
		// Standard input stream.
		// It corresponds to the C stream stdin.
		// We can use it to read input from keyboard.
		// Using the >> operator we can retreive formatted data (in our example string)
		// Declared in <iostream>
		cin >> readString;
		//cout << "READ :: " << readString << endl;

		// String comparison. Note that string comparisons are Case Sensitive
		if ( readString.compare("END") != 0 ) {
			// Add item to vector
			words.push_back(readString);
		}
		else {
			// Stop do while
			finished = true;
		}
		//cout << "\tVector Capacity :: " << words.capacity() << endl;
	} while ( !finished );

	printStringVector(words);
}