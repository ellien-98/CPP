#ifndef _TEMPLATE_CLASS_H_
#define _TEMPLATE_CLASS_H_

#include <iostream>

using namespace std;

template <typename T, int N>
class Vector{
	T v[N];
public:
	Vector() {
		// Initialize Values to Zero
		for (int i=0; i<N; i++) 
			v[i] = 0;
	}
	
	//We can use this to access the array.
	// TODO: Make this safe!
	T& operator [](int i){
		return v[i];
	}
	
	// TODO:: Implement the function so that it returns the maximum stored value
	T getMax(){
		return 0;
	}
	
	// TODO:: Implement the function so that prints the array
	void print() {
		
	}
};

#endif // _TEMPLATE_CLASS_H_
