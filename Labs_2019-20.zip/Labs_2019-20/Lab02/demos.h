void arrays_and_pointers_demo ();

void dynamic_memory_management_demo ();

void vector_demo ();

void map_demo ();

void set_demo ();

