#ifndef DEMOS_H_
#define DEMOS_H_
#include <string>
#include <vector>

// Declarations
void string_examples();
void simpleFileWriteExample ( void );
void simpleReadExample ( const char *fName );
void readWriteBinaryExample ( void );


#endif	// DEMOS_H_