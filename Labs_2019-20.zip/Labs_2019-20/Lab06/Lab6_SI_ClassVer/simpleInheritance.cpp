#include <iostream>

#include "simpleInheritance.h"

using namespace std;
using namespace SI;

// --------------------------------------------------------- //
// Point Constructor-Destructor & Member Function Definition //
// --------------------------------------------------------- //

// Constructor
Point::Point ( int newX, int newY ) 
	:x(newX), y(newY) {
	cout << "\t- Point Constructor" << endl; 
}

// Copy-Constructor
Point::Point (const Point& original)
	:x(original.x), y(original.y) {
		cout << "\t- Point Copy-Constructor" << endl; 
}

// Destructor
Point::~Point () { 
	cout << "\t- Point Destructor" << endl; 
}

void
Point::display () const {
	cout << "x: " << x << ", y: " << y << endl;
}

// ---------------------------------------------------------------------------------- //
// LabeledPoint Constructor-Destructor, Copy-Constructor & Member Function Definition //
// ---------------------------------------------------------------------------------- //

// LabeledPoint Constructor


// LabeledPoint Copy-Constructor


// LabeledPoint Destructor

// LabeledPoint display


// -------------------------------------- //
// PointFriend Member Function Definition //
// -------------------------------------- //



// ------------------------------------------------------------ //
// Friend function needs to be declared inside the SI namespace //
// ------------------------------------------------------------ //
}