#include "Complex.h"

Complex::Complex () {
	// TODO :: Implement
}

Complex::Complex (float real, float imaginary) {
	// TODO :: Implement
}

Complex Complex::operator + (const Complex& c) {
	//		   + :: (real - real, imaginary - imaginary)
	// TODO :: Implement
	return Complex();
}

bool Complex::operator == (const Complex& c) {
	// TODO :: Implement
	return true;
}

ostream& operator <<(ostream& os, const Complex& c) {
	// TODO :: Implement
	return os;
}

istream& operator >>(istream& is, Complex& c) {
	// TODO :: Implement
	return is;
}
