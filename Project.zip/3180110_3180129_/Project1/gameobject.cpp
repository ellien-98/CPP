#include "gameobject.h"
#include "game.h"

Gameobject::Gameobject(const Game& mygame)		//ta references kai ta const pedia prepei na arxikopoiounta, gia ayto einai
	: game(mygame)						//APARAITHTO to na arxikopoihsooume to game
{

}
