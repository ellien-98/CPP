
#pragma once

#define ASSET_PATH "assets\\"
#define WINDOW_WIDTH 1200		//pixel units
#define WINDOW_HEIGHT 600
#define CANVAS_WIDTH 1000		//canvas units
#define CANVAS_HEIGHT 500
